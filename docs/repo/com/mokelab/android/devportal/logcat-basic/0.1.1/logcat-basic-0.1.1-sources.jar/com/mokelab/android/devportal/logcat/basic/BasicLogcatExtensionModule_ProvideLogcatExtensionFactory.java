package com.mokelab.android.devportal.logcat.basic;

import com.mokelab.android.devportal.logcat.api.LogcatExtension;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BasicLogcatExtensionModule_ProvideLogcatExtensionFactory implements Factory<LogcatExtension> {
  @Override
  public LogcatExtension get() {
    return provideLogcatExtension();
  }

  public static BasicLogcatExtensionModule_ProvideLogcatExtensionFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static LogcatExtension provideLogcatExtension() {
    return Preconditions.checkNotNullFromProvides(BasicLogcatExtensionModule.INSTANCE.provideLogcatExtension());
  }

  private static final class InstanceHolder {
    static final BasicLogcatExtensionModule_ProvideLogcatExtensionFactory INSTANCE = new BasicLogcatExtensionModule_ProvideLogcatExtensionFactory();
  }
}
